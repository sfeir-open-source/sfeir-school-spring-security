package org.sfeir.springsecurityschool.starter;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringSecuritySchoolStarterApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringSecuritySchoolStarterApplication.class, args);
	}

}
